#!/bin/bash 

virtualenv ml2_virtualenv --system-site-packages 
source ml2_virtualenv/bin/activate 
pip install pip --upgrade 
pip install tensorflow=="1.0.0" 
pip install --upgrade jupyter
pip install protobuf --upgrade 
pip install numpy
pip install matplotlib
pip install datetime
