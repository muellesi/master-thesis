from ..environment import Environment
import ple
from ple import PLE

GAMES = [
        "Catcher",
        "FlappyBird",
        "MonsterKong",
        "Pixelcopter",
        "Pong",
        "PuckWorld",
        "RaycastMaze",
        "Snake",
        "WaterWorld"
        ]


def create_game(config):
  name = config.env_name
  game = None
  if name == "Pong":
    game = ple.games.Pong(width=config.state_width, height=config.state_height)
  elif name == "Catcher":
    game = ple.games.Catcher(width=config.state_width, height=config.state_height)
  elif name == "FlappyBird":
    game = ple.games.FlappyBird(width=config.state_width, height=config.state_height)
  elif name == "MonsterKong":
    game = ple.games.MonsterKong(width=config.state_width, height=config.state_height)
  elif name == "Pixelcopter":
    game = ple.games.Pixelcopter(width=config.state_width, height=config.state_height)
  elif name == "PuckWorld":
    game = ple.games.PuckWorld(width=config.state_width, height=config.state_height)
  elif name == "RaycastMaze":
    game = ple.games.RaycastMaze(width=config.state_width, height=config.state_height)
  elif name == "Snake":
    game = ple.games.Snake(width=config.state_width, height=config.state_height)
  elif name == "WaterWorld":
    game = ple.games.WaterWorld(width=config.state_width, height=config.state_height)
  else:
    print "Error: No valid name for a game was given!"

  return game

class PleEnvironment(Environment):

  def __init__(self, config):
    super(PleEnvironment, self).__init__(config)
    self.game = create_game(config)
    self.env = PLE(
            self.game,
            fps=30,
            display_screen=config.display,
            force_fps=True,
            frame_skip=1,
            num_steps=config.action_repeat,
            reward_values={
                "positive": 1.0,
                "negative": -1.0,
                "tick": 0.0,
                "loss": -5.0,
                "win": 5.0
                },
            rng=config.random_start
            )
    self.reward = 0

  def _start_new_game(self):
    self.env.reset_game()
    self.env.init()

  def _step(self, action_index):
    action = self.env.getActionSet()[action_index]
    self.env.act(action)

  def act(self, action_index, is_training=True):
    action = self.env.getActionSet()[action_index]
    self.reward = self.env.act(action)
    return self.state

  def game_state(self):
    """ Returns a non-visual representation of the game state"""
    return self.env.getGameState()

  def _get_action_size(self):
    return len(self.env.getActionSet())

  def _get_lives(self):
    return self.env.lives()

  def get_game_names(self):
    return GAMES


class VisualPleEnvironment(PleEnvironment):

    def __init__(self, config):
      super(VisualPleEnvironment, self).__init__(config)
      self.use_color = config.use_color

    def _get_screen(self):
      frame = []
      if self.use_color:
        frame = self.env.getScreenRGB()
      else:
        frame = self.env.getScreenGrayscale()
      return frame / 255.

    def _get_state(self):
      return self.screen, self.reward, self.env.game_over()
