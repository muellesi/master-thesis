import random
import abc

class Environment(object):
  __metaclass__ = abc.ABCMeta

  def __init__(self, config):
    self.config = config
    self.random_start = config.random_start

  def new_game(self):
    self._start_new_game()
    return self.state

  def new_random_game(self):
    self.new_game()
    for _ in xrange(random.randint(0, self.random_start - 1)):
      self.act(0)
    return self.state

  @abc.abstractmethod
  def _start_new_game(self):
    """ Method to start the game environment """

  @abc.abstractmethod
  def _step(self, action):
    """ Method to perform the given action in the environment """

  @abc.abstractmethod
  def get_game_names(self):
    """ Return the name of possible games/modes for this environment """

  def _random_step(self):
    action = random.randint(0, self.action_size - 1)
    self._step(action)

  @abc.abstractmethod
  def act(self, action, is_training=True):
    """ Method to perform the given action and calculate the reward internally. """

  @property
  def screen(self):
    return self._get_screen()

  @property
  def action_size(self):
    return self._get_action_size()

  @property
  def lives(self):
    return self._get_lives()

  @property
  def state(self):
    return self._get_state()

  @abc.abstractmethod
  def _get_screen(self):
    """ Method to return the screen of the environment """

  @abc.abstractmethod
  def _get_action_size(self):
    """ Method to return the number of actions of the environment """

  @abc.abstractmethod
  def _get_lives(self):
    """ Method to return the number of lives for the current game """

  @abc.abstractmethod
  def _get_state(self):
    """ Method to return the state of the current game """
