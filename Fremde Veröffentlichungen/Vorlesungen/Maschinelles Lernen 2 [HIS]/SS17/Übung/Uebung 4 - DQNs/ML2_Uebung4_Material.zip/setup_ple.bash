#!/bin/bash

pip install pygame --user
if [[ ! -d ple ]]; then
  git clone https://github.com/ntasfi/PyGame-Learning-Environment ple
fi
cd ple/
pip install --user -e .
